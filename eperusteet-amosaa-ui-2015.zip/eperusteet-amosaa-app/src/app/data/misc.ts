namespace Misc {
    let id = 0;
    export const uniqueId = () => id++;
}
