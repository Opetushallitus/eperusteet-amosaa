namespace Constants {
    export const debounceDelay = 300;
    export const tosTilat = ["poistettu", "luonnos", "valmis", "julkaistu"];
    export const tosTyypit = ["pohja", "ops", "yleinen", "yhteinen"];
}
