namespace Amosaa {
    export const tuetutKoulutustyypit = () => [
        "koulutustyyppi_1",
        "koulutustyyppi_11",
        "koulutustyyppi_12",
        "koulutustyyppi_5",
        "koulutustyyppi_18"
    ];

    export const valmaTelmaKoulutustyypit = () => [
        "koulutustyyppi_5",
        "koulutustyyppi_18"
    ]
}
