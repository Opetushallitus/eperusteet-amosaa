angular.module("app").config($stateProvider =>
        $stateProvider.state("root.koulutustoimija.hallinta.opspaivitettavat", {
            url: "/opspaivitettavat"
        })
    );
