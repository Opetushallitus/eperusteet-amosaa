angular.module("app").config($stateProvider =>
        $stateProvider.state("root.koulutustoimija.hallinta.tiedot", {
            url: "/tiedot"
        })
    );
