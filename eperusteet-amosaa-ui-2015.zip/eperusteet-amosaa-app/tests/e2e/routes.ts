describe('Testing all state manager routes', () => {
    browser.get('http://localhost:9030/#/fi/routes');
});
